$(document).ready(function() {
    $("#serv-inp").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $("#serv-table tr").filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1)
        });
    });
});



$('.home-ss-tab').click(function() {
    if ($(this).hasClass('active')) {
        $(this).find('.ss-tab-content').slideToggle(200);
        $(this).toggleClass('active');
    } else {
        $('.home-ss-tab').removeClass('active');
        $('.home-ss-tab > .ss-tab-content').slideUp(200);
        $(this).find('.ss-tab-content').slideToggle(200);
        $(this).toggleClass('active');
    }
});

$('.tos-nav-btn').click(function() {
    if ($(this).hasClass('active')) {

    } else {
        let getFor = $(this).attr('for');
        $('.tos-nav-btn').removeClass('active');
        $(this).toggleClass('active');
        $('.tos-tab').removeClass('active');
        $('#' + getFor + '.tos-tab').addClass('active')

    }
});

function menuToggle() {
    $(".dashboard").toggleClass('menu-active');
}

function homeMenuToggle() {
    console.log('sa');
    $(".head-menu").toggleClass('active');
    $('body').toggleClass('body-pause');
    $('.home-menu-btn > .fas').toggleClass('fa-bars')
    $('.home-menu-btn > .fas').toggleClass('fa-times')
}